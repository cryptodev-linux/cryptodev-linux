struct af_alg_cipher_data
{
	int tfmfd;
	int opfd;
	__u32 type;
	unsigned char iv[16];
	int pipes[2];
};

#define SPLICE
//#define ENC_ONLY

#ifndef PAGE_SIZE
# define PAGE_SIZE 4096
#endif

int af_alg_aes_encrypt(struct af_alg_cipher_data *ctx, unsigned char *out_arg, const unsigned char *in_arg, unsigned int nbytes);
int af_alg_aes_cleanup_key(struct af_alg_cipher_data *ctx);
int af_alg_aes_init_key (struct af_alg_cipher_data *ctx, const unsigned char *key, int key_size, const unsigned char *iv, int enc);




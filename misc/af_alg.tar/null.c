/*  af_alg benchmark
 *
 *  Copyright (C) 2011 by Nikos Mavrogiannopoulos <nmav@gnutls.org>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include <memory.h>
#include <sys/socket.h>
#include <linux/if_alg.h>
#include <unistd.h>
#include <sys/param.h>
#include <ctype.h>
#include "e_af_alg.h"

#ifndef SOL_ALG
#define SOL_ALG 279
#endif
#define SPLICE_F_GIFT	(0x08)	/* pages passed in are a gift */

/* Socket options */
#define ALG_SET_KEY			1
#define ALG_SET_IV			2
#define ALG_SET_OP			3

#define AES_BLOCK_SIZE 16


#define ERR() { perror("unknown"); fprintf(stderr, "line: %d\n", __LINE__); abort(); }

int af_alg_aes_init_key (struct af_alg_cipher_data * acd, const unsigned char *key, int key_size, const unsigned char *iv, int enc)
{
	struct sockaddr_alg sa = {
		.salg_family = AF_ALG,
		.salg_type = "skcipher",
		.salg_name = "ecb(cipher_null)"
	};
	
	if( enc)
		acd->type = ALG_OP_ENCRYPT;
	else
		acd->type = ALG_OP_DECRYPT;

	if((acd->tfmfd = socket(AF_ALG, SOCK_SEQPACKET, 0)) == -1)
		ERR();
	
	if( bind(acd->tfmfd, (struct sockaddr*)&sa, sizeof(sa)) == -1 )
		ERR();

        acd->opfd = accept(acd->tfmfd, NULL, 0);
        if (acd->opfd == -1) {
          ERR();
        }
        
        memcpy(acd->iv, iv, 16);

#if defined(SPLICE) && !defined(ENC_ONLY)
	if (pipe(acd->pipes)==-1)
	  ERR();
#endif

	return 1;
}

int af_alg_aes_cleanup_key(struct af_alg_cipher_data* acd)
{
	if( acd->tfmfd != -1 )
		close(acd->tfmfd);
	if( acd->opfd != -1 )
		close(acd->opfd);

#if defined(SPLICE) && !defined(ENC_ONLY)
        close(acd->pipes[0]);
        close(acd->pipes[1]);
#endif

	return 1;
}

int af_alg_aes_encrypt(struct af_alg_cipher_data *acd, unsigned char *out_arg, const unsigned char *in_arg, unsigned int nbytes)
{
	unsigned char cbuf[CMSG_SPACE(4)];
	struct msghdr msg;
	struct cmsghdr *cmsg;
	struct iovec iov;
	struct af_alg_iv *ivm;
	__u32 t = ALG_OP_ENCRYPT;
	int ret, nbytes_pg_align;

	memset(&msg, 0, sizeof(msg));

#if defined(SPLICE) && defined(ENC_ONLY)
	if (pipe(acd->pipes)==-1)
	  ERR();
#endif
	
	msg.msg_control = cbuf;
	msg.msg_controllen = sizeof(cbuf);

	cmsg = CMSG_FIRSTHDR(&msg);
	if (cmsg == NULL)
	  ERR();
	
	cmsg->cmsg_level = SOL_ALG;
	cmsg->cmsg_type = ALG_SET_OP;
	cmsg->cmsg_len = CMSG_LEN(4);
	memcpy(CMSG_DATA(cmsg), &t, 4);
	
	nbytes_pg_align = (((nbytes+PAGE_SIZE)/PAGE_SIZE)*PAGE_SIZE);
	iov.iov_base = (void*)in_arg;

#ifndef SPLICE
	iov.iov_len = nbytes_pg_align;
	msg.msg_iov = &iov;
	msg.msg_iovlen = 1;
#else
	iov.iov_len = nbytes;
	msg.msg_iovlen = 0;
        msg.msg_flags = MSG_MORE;
#endif

	ret = sendmsg(acd->opfd, &msg, 0);
#ifndef SPLICE
	if (ret != nbytes) {
	  if (ret == -1) perror("sendmsg");
	  fprintf(stderr, "%d: written %d, expected %d\n", __LINE__, ret, nbytes);
	  abort();
        }
#else
        if (vmsplice(acd->pipes[1], &iov, 1, SPLICE_F_GIFT)==-1)
          ERR();

        if (splice(acd->pipes[0], NULL, acd->opfd, NULL, nbytes, 0) == -1)
          ERR();
#endif

	ret = read(acd->opfd, out_arg, nbytes);
	if (ret != nbytes) {
	  if (ret == -1) perror("read");
	  fprintf(stderr, "%d: read %d, expected %d\n", __LINE__, ret, nbytes);
	  abort();
        }

#if defined(SPLICE) && defined(ENC_ONLY)
        close(acd->pipes[0]);
        close(acd->pipes[1]);
#endif

	return 0;
}


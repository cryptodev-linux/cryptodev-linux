/*  cryptodev_test - simple benchmark tool for cryptodev
 *
 *  Copyright (C) 2010 by Phil Sutter <phil.sutter@viprinet.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <signal.h>
#include <unistd.h>
#include <linux/netlink.h>
#include "e_af_alg.h"

static double udifftimeval(struct timeval start, struct timeval end)
{
	return (double)(end.tv_usec - start.tv_usec) +
	    (double)(end.tv_sec - start.tv_sec) * 1000 * 1000;
}

static int must_finish = 0;

static void alarm_handler(int signo)
{
	must_finish = 1;
}

static char *si_units[] = { "", "K", "M", "G", "T", 0};

static void value2human(double bytes, double time, double* data, double* speed,char* metric)
{
	int unit = 0;

	*data = bytes;
	
	while (*data > 1000 && si_units[unit + 1]) {
		*data /= 1000;
		unit++;
	}
	*speed = *data / time;
	sprintf(metric, "%sB", si_units[unit]);
}

int encrypt_data(int chunksize)
{
	void *buffer;
	char iv[32];
	static int val = 23;
	struct timeval start, end;
	double total = 0;
	double secs, ddata, dspeed;
	char metric[16];
	struct af_alg_cipher_data hd;
	int ret;

	memset(iv, 0x23, 32);

	if (posix_memalign(&buffer, PAGE_SIZE, chunksize) < 0) {
		perror("posix memalign");
		return 1;
	}

	printf("\tEncrypting in chunks of %d bytes: ", chunksize);
	fflush(stdout);

	memset(buffer, val++, chunksize);

	must_finish = 0;

#ifdef ENC_ONLY
        ret = af_alg_aes_init_key(&hd, "\x6e\x29\x20\x11\x90\x15\x2d\xf4\xee\x05\x81\x39\xde\xf6\x10\xbb", 16, iv, 1);
	if (ret < 0) {
		fprintf(stderr, "Error: %s:%d\n", __func__, __LINE__);
		perror("ioctl(NCRIO_KEY_INIT)");
		return 1;
	}
#endif
	alarm(5);

	gettimeofday(&start, NULL);
	do {
		size_t output_size;

#ifndef ENC_ONLY
	        ret = af_alg_aes_init_key(&hd, "\x6e\x29\x20\x11\x90\x15\x2d\xf4\xee\x05\x81\x39\xde\xf6\x10\xbb", 16, iv, 1);
		if (ret < 0) {
			fprintf(stderr, "Error: %s:%d\n", __func__, __LINE__);
			perror("ioctl(NCRIO_KEY_INIT)");
			return 1;
		}
#endif
	        ret = af_alg_aes_encrypt(&hd, buffer, buffer, chunksize);
		if (ret < 0) {
			fprintf(stderr, "Error: %s:%d\n", __func__, __LINE__);
			perror("ioctl(NCRIO_SESSION_UPDATE)");
			return 1;
		}
#ifndef ENC_ONLY
                af_alg_aes_cleanup_key(&hd);
#endif
		total += chunksize;
	} while (must_finish == 0);
	gettimeofday(&end, NULL);

#ifdef ENC_ONLY
        af_alg_aes_cleanup_key(&hd);
#endif

	secs = udifftimeval(start, end) / 1000000.0;

	value2human(total, secs, &ddata, &dspeed, metric);
	printf("done. %.2f %s in %.2f secs: ", ddata, metric, secs);
	printf("%.3f %s/sec\n", dspeed, metric);

	free(buffer);

	return 0;
}

int main(void)
{
	int i;

	signal(SIGALRM, alarm_handler);

	fprintf(stderr, "\nTesting AF_ALG: \n");
	for (i = 512; i <= 64*1024; i *= 2) {
		if (encrypt_data(i))
			break;
	}

	return 0;
}
